import { Box } from "@mui/material";

export function GridCell({data}){
    return(
        <Box sx={{border:" 1px solid gray", padding: "2px"}}>
            {data.toString()}
        </Box>
    )
}
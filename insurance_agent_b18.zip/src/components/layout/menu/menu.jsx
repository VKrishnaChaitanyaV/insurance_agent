import './menu.css';
import {Link} from 'react-router-dom';

export const Menu = function(){
    return(
        <div>
            <ul className="menu">
                <li>
                    <Link to='/dashboard'>Dashboard</Link>
                </li>
                <li>
                    <Link to='/contact-management'>Contact Management</Link>
                </li>
                <li>
                    <Link to='/lead-management'>Lead Management</Link>
                </li>
                <li>
                    <Link to='/client-management'>Client Management</Link>
                </li>
            </ul>
        </div>
    )
}
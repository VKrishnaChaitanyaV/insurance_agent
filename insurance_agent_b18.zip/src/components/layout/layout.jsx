import { AppRouter } from '../../app.router';
import { AppRouter1 } from '../../app.router1';
import './layout.css';
import {Menu} from './menu/menu';

export function Layout(props) {
    return (
        <div className='maind'>
            <div className='h-5 bg-light'>

            </div>
            <div className='h-92 row maind'>
                <div className='col-2 bg-light'>
                    <Menu></Menu>
                </div>
                <div className='col-10 bg-white'>
                    {
                        props.children
                    }
                </div>   

            </div>
        </div>
    )
}
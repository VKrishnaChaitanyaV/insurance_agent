import React from "react";

export class Dashboard extends React.Component { //inheritance
    constructor(props) {
        console.log("Constructor");
        super(); //Base class constructor
        this.state = {
            
        }
    }

    static getDerivedStateFromProps() {
        console.log("getDerivedStateFromProps");
       
    }

    shouldComponentUpdate() {
        console.log("shouldComponentUpdate");
        return true;
    }

    getSnapshotBeforeUpdate() {
        console.log("getSnapshotBeforeUpdate");
    }

    componentDidMount() {
        console.log("componentDidMount");
    }

    componentDidUpdate() {
        console.log("ComponentDidUpdate");
    }

    componentWillUnmount() {
        alert("Unloading");
    }

    render() {
        console.log("Render");
        return (
            <div>
                Dashboard
            </div>
        )
    }

}
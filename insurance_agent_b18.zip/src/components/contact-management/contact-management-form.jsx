import { Box, Button, Checkbox, Container, FormControl, FormControlLabel, FormLabel, Grid, Input, InputLabel, MenuItem, Radio, RadioGroup, Select, TextField } from "@mui/material"

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";

export const ContactManagementForm = (props) => {

    const [btnText, setBtntext] = useState("Add Contact");

    const {
        register,
        handleSubmit,
        setValue,
        formState: { errors }
    } = useForm();

    function contactData(data) {
        props.contactFormData(data);
    }

    useEffect(()=>{
            
        let keys = Object.keys(props.data);
        if(keys.length >0) {
            setBtntext("Update Contact");
            keys.forEach((key)=>{
                setValue(key, props.data[key]);
            });
        }
        else {
            setValue("id", 0);
        }
            
    }, []);

    return (
        <Box mr={2}>
            <Container sx={{ border: "1px solid gray" }}>
                <form onSubmit={handleSubmit((data)=>{
                    contactData(data)
                })}>
                    <input type="hidden" {...register('id')}></input>
                    <Grid container>
                        <Grid item xs={2} mt={2}>
                            <FormControl>
                                <FormLabel>First Name</FormLabel>
                            </FormControl>
                        </Grid>
                        <Grid item xs={10} mt={2}>
                            <TextField type="text" fullWidth variant="outlined" {...register('firstName', { required: true })}></TextField>
                            {errors.firstName && errors.firstName.type == 'required' && <div className="text-danger"> FirstName is Required </div>}
                        </Grid>
                    </Grid>
                    <Grid container>
                        <Grid item xs={2} mt={2}>
                            <FormControl>
                                <FormLabel>Last Name</FormLabel>
                            </FormControl>
                        </Grid>
                        <Grid item xs={10} mt={2}>
                            <TextField type="text" fullWidth variant="outlined" {...register('lastName', { required: true })}></TextField>
                            {errors.lastName && errors.lastName.type == 'required' && <div className="text-danger"> LastName is Required </div>}
                        </Grid>
                    </Grid>
                    <Box>
                        <Grid container>
                            <Grid item xs={2} mt={2}>
                                <FormLabel>Email</FormLabel>
                            </Grid>
                            <Grid item xs={10} mt={2}>
                                <TextField type="email" fullWidth variant="outlined" {...register('email', { required: true })}></TextField>
                                {errors.email && errors.email.type == 'required' && <div className="text-danger"> Email is Required </div>}
                            </Grid>
                        </Grid>
                    </Box>
                    <Box>
                        <Grid container>
                            <Grid item xs={2} mt={2}>
                                <FormLabel>Phone Number</FormLabel>
                            </Grid>
                            <Grid item xs={10} mt={2}>
                                <TextField type="number" fullWidth variant="outlined" {...register('phoneNumber', { required: true })}></TextField>
                                {errors.phoneNumber && errors.phoneNumber.type == 'required' && <div className="text-danger"> Phone Number is Required </div>}
                            </Grid>
                        </Grid>

                    </Box>
                    <Box>
                        <Grid container>
                            <Grid item xs={2} mt={2}>
                                <FormLabel>DOB</FormLabel>
                            </Grid>
                            <Grid item xs={10} mt={2}>
                                <TextField type="date" fullWidth variant="outlined" {...register('dob', { required: true })}></TextField>
                                {errors.dob && errors.dob.type == 'required' && <div className="text-danger"> DOB Number is Required </div>}
                            </Grid>
                        </Grid>

                    </Box>
                    <Box>
                        <Grid container>
                            <Grid item xs={2} mt={2}>
                                <FormLabel>Address</FormLabel>
                            </Grid>
                            <Grid item xs={10} mt={2} mb={2}>
                                <TextField type="textarea" fullWidth variant="outlined" {...register('address')}></TextField>
                            </Grid>
                        </Grid>
                    </Box>
                    <Box>
                        <Grid container>
                            <Grid item xs={2} mt={1}>
                                <FormLabel>Gender</FormLabel>
                            </Grid>
                            <Grid item xs={10}>
                                <RadioGroup>
                                    <Grid container>
                                        <Grid item xs={2}>
                                            <FormControlLabel control={<Radio {...register('gender')}></Radio>} value="male" label="Male"></FormControlLabel>
                                        </Grid>
                                        <Grid item xs={10}>
                                            <FormControlLabel control={<Radio {...register('gender')}></Radio>} value="Female" label="Female"></FormControlLabel>
                                        </Grid>
                                    </Grid>
                                </RadioGroup>
                            </Grid>
                        </Grid>

                    </Box>

                    <Box mt={2}>
                        <Checkbox {...register('isLead')}></Checkbox>
                        <FormLabel>Converted to Lead</FormLabel>
                    </Box>

                    <Box mb={2}>
                        <Button type="submit" variant="contained" color="success">{ btnText }</Button>
                        <Button variant="contained" color="warning" onClick={() => {
                            props.closePopup()
                        }}>Cancel</Button>

                    </Box>
                </form>
            </Container>
        </Box>
    )
}
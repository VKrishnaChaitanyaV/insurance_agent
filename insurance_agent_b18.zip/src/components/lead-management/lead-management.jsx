import { Box, Button, Grid } from "@mui/material";
import { Link, Route, Routes, useNavigate } from "react-router-dom";
import { BasicInfo } from "./basic-info/basic-info";
import { Policy } from "./policy/policy";
import { Address } from "./address/address";
import { Nominee } from "./nominee/nominee";
import { Payment } from "./payment/payment";
import { AppRouter1 } from "../../app.router1";
import './lead-management.css';
import { GridComponent } from "../shared/grid/grid";
import { getContactsList } from "../../services/contact-management.service";
import { useEffect, useState } from "react";


export const LeadManagement = () => {

    const gridHeaders = ["Is Lead", "ID", "Fist Name", "Last Name", "Email", "Phone Number", "DOB",  "Gender", "Address"];
    const gridKeys = ["isLead","id", "firstName", "lastName", "email", "phoneNumber", "dob", "gender", "address"];
    const gridCellWidth = [1, 1, 2, 1, 2, 1, 1, 1, 1];

    const [contactList, setContactList] = useState([]);
    const navigate = useNavigate();

    function getContactList() {
        getContactsList().then((res)=>{
            let data = res.data.filter((item)=> item.isLead == true);
            setContactList(data);
        });
    }

    function navigateToEditLead(item) {
        navigate('/edit-lead/'+item.id)
    }

    useEffect(()=>{
        getContactList();
    }, []);

    return (
        <Box>
            <Grid container mb={2}>
                <Grid item xs={10} component={"h3"}>
                    LEAD MANAGEMENT
                </Grid>
            </Grid>
           
            <Box mt={2}></Box>

            <GridComponent headers={gridHeaders} keys={gridKeys} data={contactList} cellWidth={gridCellWidth} showEditDelete={true}
                editGridItem={(item)=>{
                    navigateToEditLead(item)
                }}
            ></GridComponent>
        </Box>

    )
}


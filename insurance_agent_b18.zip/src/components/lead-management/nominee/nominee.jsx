import { Box, Button, Container, FormControl, FormLabel, Grid, InputLabel, TextField } from "@mui/material"
import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import { getNominee, saveNominee, updateNominee } from "../../../services/contact-management.service";

export const Nominee = (props) => {

    const {
        register,
        setValue,
        handleSubmit,
        formState: { errors }
    } = useForm();

    const [nomineeId, setNomineeId] = useState(0);
    const [btnText, setbtnText] = useState("Save");

    function saveData(data) {
        let nomineeDetails = { contactId: props.id, ...data };

        if (nomineeId != 0) {
            updateNominee(nomineeDetails, nomineeId).then((res) => {
                alert("Nominee Updated.!");
            });
        }
        else {
            saveNominee(nomineeDetails).then(res => {
                alert("Nominee Saved.!");
            })
        }
    }

    async function getData() {
        let res = await getNominee();
        if (res.data) {
            let data = res.data.find(item => item.contactId == props.id);

            if (data) {
                let keys = Object.keys(data);

                keys.forEach((key) => {
                    setValue(key, data[key]);

                });

                setbtnText("Update");
                setNomineeId(data.id);
            }
        }
    }

    useEffect(() => {
        getData();
    }, []);


    return (
        <Box mr={2}>
            <Grid container mb={2}>
                <Grid item xs={10} component={"h4"}>
                    <h4>NOMINEE DETAILS</h4>
                </Grid>

            </Grid>

            <Container sx={{ border: "1px solid gray" }}>
                <form onSubmit={handleSubmit((data) => {
                    saveData(data)
                })}>
                    <Grid container>
                        <Grid item xs={2} mt={2}>
                            <FormControl>
                                <FormLabel>Nominee Name</FormLabel>
                            </FormControl>
                        </Grid>
                        <Grid item xs={10} mt={2}>
                            <TextField type="text" fullWidth variant="standard" {...register('nomineeName')}></TextField>
                        </Grid>
                    </Grid>
                    <Grid container>
                        <Grid item xs={2} mt={2}>
                            <FormControl>
                                <FormLabel>Relationship</FormLabel>
                            </FormControl>
                        </Grid>
                        <Grid item xs={10} mt={2}>
                            <TextField type="text" fullWidth variant="standard" {...register('relationship')}></TextField>
                        </Grid>
                    </Grid>

                    <Box>
                        <Grid container>
                            <Grid item xs={2} mt={2}>
                                <InputLabel>Nominee Age</InputLabel>
                            </Grid>
                            <Grid item xs={10} mt={2}>
                                <TextField type="text" fullWidth variant="standard" {...register('nomineeAge')}></TextField>
                            </Grid>
                        </Grid>
                    </Box>
                    <Box>
                        <Grid container>
                            <Grid item xs={2} mt={2}>
                                <InputLabel>Nominee Address</InputLabel>
                            </Grid>
                            <Grid item xs={10} mt={2}>
                                <TextField type="text" fullWidth variant="outlined" {...register('nomineeAddress')}></TextField>
                            </Grid>
                        </Grid>
                    </Box>


                    <Box mb={1}>
                        <Button type="submit" variant="contained" color="success">{btnText}</Button>
                    </Box>
                </form>
            </Container>
        </Box>
    )
}
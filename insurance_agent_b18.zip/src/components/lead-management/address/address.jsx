import { Box, Checkbox, Button, Container, FormControl, FormLabel, Grid, InputLabel, TextField } from "@mui/material"

import { useForm } from "react-hook-form";
import { getAddress, saveAddress, updateAddress } from "../../../services/contact-management.service";
import { useEffect, useState } from "react";

export const Address = (props) => {

    const {
        register,
        setValue,
        handleSubmit,
        formState: { errors }
    } = useForm();

    const [addressid, setAddressId] = useState(0);
    const [btnText, setBtnText] = useState("Save");

    function saveData(data) {
        //alert(JSON.stringify(data));
        //contactId: props.id

        let address = {"contactId": props.id, ...data };
        
        if(addressid != 0)
        {
            updateAddress(address, addressid).then((res)=>{
                alert("Address Updated.!");
            })
        }
        else {
            saveAddress(address).then(res=>{
                alert("Address Saved.!");
            })
        }
    }

    useEffect(()=>{
        getAddressDetails();
    }, []);

    async function getAddressDetails() {
        let res = await getAddress();
        if(res.data.length>0) {
            let addressRecord = res.data.find(item=>item.contactId == props.id);
            if(addressRecord) {
                setAddressId(addressRecord.id);
                setBtnText("Update");
                let keys = Object.keys(addressRecord);
                keys.forEach((key)=>{
                    setValue(key, addressRecord[key]);
                });
            }            
        }
    }

    return (
        <Box mr={2}>
            <Grid container mb={2}>
                <Grid item xs={10} component={"h4"}>
                    ADDRESS
                </Grid>

            </Grid>

            <Container sx={{ border: "1px solid gray" }}>
                <form onSubmit={handleSubmit((data)=>{
                    saveData(data);
                })}>
                    <Grid container>
                        <Grid item xs={2} mt={1}>
                            <FormControl>
                                <FormLabel>H.No.</FormLabel>
                            </FormControl>
                        </Grid>
                        <Grid item xs={10} mt={1}>
                            <TextField type="text" fullWidth variant="standard" {...register('houseno')}></TextField>
                        </Grid>
                    </Grid>
                    <Grid container>
                        <Grid item xs={2} mt={1}>
                            <FormControl>
                                <FormLabel>Street</FormLabel>
                            </FormControl>
                        </Grid>
                        <Grid item xs={10} mt={1}>
                            <TextField type="text" fullWidth variant="standard" {...register('street', { required: true })}></TextField>
                            {errors.street && errors.street.type == "required" && <div className="text-danger"> Street Info is required. </div>}
                        </Grid>
                    </Grid>

                    <Box>
                        <Grid container>
                            <Grid item xs={2} mt={1}>
                                <InputLabel>Area</InputLabel>
                            </Grid>
                            <Grid item xs={10} mt={1}>
                                <TextField type="text" fullWidth variant="standard" {...register('area')}></TextField>
                            </Grid>
                        </Grid>
                    </Box>
                    <Box>
                        <Grid container>
                            <Grid item xs={2} mt={1}>
                                <InputLabel>Locality</InputLabel>
                            </Grid>
                            <Grid item xs={10} mt={1}>
                                <TextField type="text" fullWidth variant="standard" {...register('locality')}></TextField>
                            </Grid>
                        </Grid>
                    </Box>
                    <Box>
                        <Grid container>
                            <Grid item xs={2} mt={1}>
                                <InputLabel>District</InputLabel>
                            </Grid>
                            <Grid item xs={10} mt={1}>
                                <TextField type="text" fullWidth variant="standard" {...register('district')}></TextField>
                            </Grid>
                        </Grid>
                    </Box>
                    <Box>
                        <Grid container>
                            <Grid item xs={2} mt={1}>
                                <InputLabel>State</InputLabel>
                            </Grid>
                            <Grid item xs={10} mt={1}>
                                <TextField type="text" fullWidth variant="standard" {...register('state')}></TextField>
                            </Grid>
                        </Grid>
                    </Box>
                    <Box>
                        <Grid container>
                            <Grid item xs={2} mt={1}>
                                <InputLabel>PinCode</InputLabel>
                            </Grid>
                            <Grid item xs={10} mt={1}>
                                <TextField type="number" fullWidth variant="standard" {...register('pincode')}></TextField>
                            </Grid>
                        </Grid>
                    </Box>

                    <Box mb={1}>
                        <Button type="submit" variant="contained" color="success">{btnText}</Button>

                    </Box>
                </form>
            </Container>
        </Box>
    )
}
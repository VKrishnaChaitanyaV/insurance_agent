import { Box, Card, CardContent, CardHeader, Grid, MenuItem, Select, TextField, Button } from "@mui/material"
import { useEffect, useState } from "react"
import { getPackages, getPolicy, savePolicy } from "../../../services/contact-management.service"
import { useForm } from "react-hook-form";

export const Policy = (props) => {

    const [packages, setPackages] = useState([]);
    const [packageItem, setPackageItem] = useState({});
    const [packageid, setPackageId] = useState(0);

    const {
        register,
        setValue,
        handleSubmit,
        formState: { errors }
    } = useForm();

    useEffect(() => {
        getPackageDetails();
    }, []);

    async function getPackageDetails() {
        let res = await getPackages();
        setPackages(res.data);

        let policies = await getPolicy();

        if(policies.data) {
            let filterdata = policies.data.find((item) => item.contactId == props.id);
            setPackageId(filterdata.pacakgeId);
            
            if(filterdata) {
                let keys = Object.keys(filterdata);
                keys.forEach((key)=>{
                    setValue(key, filterdata[key]);
                });
            }

            let packageItemData = res.data.find(item => item.id == filterdata.pacakgeId);
            alert(JSON.stringify(packageItemData));
            setPackageItem(packageItemData);
        }
    }

    function bindPackage(item) {
        let data = packages.find(d => d.id == item.target.value);
        setPackageItem(data);
    }

    function saveData(data) {
        let policyData = { contactId: props.id, ...data };
        savePolicy(policyData).then((res)=>{
            alert("Policy Added.!");
        })
    }

    return (
        <Box>
            <form onSubmit={
                handleSubmit((data)=>{
                    saveData(data)
                })
            }>
                <Grid container>
                    <Grid item xs={3}>
                        <div>Select Package</div>
                        <Select fullWidth size="small" value={packageid} {...register('pacakgeId')} onChange={(item) => {
                            bindPackage(item)
                        }}>
                            {
                                packages && packages.map(item =>
                                    <MenuItem value={item.id}> {item.title} </MenuItem>
                                )
                            }

                        </Select>
                    </Grid>
                    <Grid item xs={3} ml={2}>
                        <div>Select Start Date:</div>
                        <TextField type="date" size="small" {...register('startDate')} fullWidth></TextField>
                    </Grid>
                </Grid>
                <Card sx={{ width: "55%" }} mt={2}>
                    <h3 className="mt-2">Package Details</h3>
                    <hr></hr>
                    <CardContent>
                        {
                            packageItem &&
                            <>
                                <Grid container>
                                    <Grid item xs={2}> Title </Grid>
                                    <Grid item xs={2}> {packageItem.title} </Grid>
                                </Grid>
                                <Grid container>
                                    <Grid item xs={2}> Amount </Grid>
                                    <Grid item xs={2}> {packageItem.amount} </Grid>
                                </Grid>
                                <Grid container>
                                    <Grid item xs={2}> Days </Grid>
                                    <Grid item xs={2}> {packageItem.days} </Grid>
                                </Grid>
                                <Grid container>
                                    <Grid item xs={2}> Description </Grid>
                                    <Grid item xs={4}> {packageItem.desc} </Grid>
                                </Grid>
                            </>
                        }

                    </CardContent>
                </Card>
                <Box mb={1}>
                    <Button disabled={ packageid>0 } type="submit" variant="contained" color="success">Save</Button>
                </Box>
            </form>
        </Box>
    )
}
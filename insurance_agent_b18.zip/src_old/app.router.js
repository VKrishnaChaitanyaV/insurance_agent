import { Route, Routes } from "react-router-dom"
import { Dashboard } from "./components/dashboard/dashboard"
import { LeadManagemenet } from "./components/lead-management/lead-managemenet"

export const AppRouter = () => {
    return (
        <Routes>
            <Route path="/dashboard" element={<Dashboard></Dashboard>}></Route>
            <Route path="/lead-management" element={<LeadManagemenet></LeadManagemenet>}></Route>
        </Routes>
    )
}
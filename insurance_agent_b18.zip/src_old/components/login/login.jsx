import { Password } from "@mui/icons-material"
import { Box, Container, FormControl, FormHelperText, Input, InputLabel, Button, TextField } from "@mui/material"



export const Login = ()=> {
    return (
    <Box>
        <Container maxWidth="sm" sx={{border: "1px solid gray", padding: "5px"}}>
            <Box component="h2" ml>Login</Box>
            <Box mt={3}>
                <FormControl fullWidth>
                    <InputLabel>Email Address</InputLabel>
                    <Input></Input>
                </FormControl>
            </Box>
            <Box mt={3}>
                {/* <FormControl>
                    <InputLabel>Password</InputLabel>
                    <Input></Input>
                </FormControl> */}
                <TextField fullWidth type="password" variant="standard" placeholder="Enter Password"></TextField>
            </Box>
            <Box mt={3}>
                <Button variant="contained">Login</Button>
            </Box>
        </Container>
    </Box>
    )
}

import { Box, Container, InputLabel, Grid, FormControl, Input, TextField, Radio, RadioGroup, FormControlLabel, FormLabel, Select, MenuItem, Checkbox, Button } from "@mui/material"
import { saveAgent } from "../../services/agent-registration.service";
import { useRef } from "react";


export const Registration = () => {

    const firstNameRef = useRef("");
    const lastNameRef = useRef("");
    const emailRef = useRef("");
    const dobRef = useRef("");
    const genderMaleRef = useRef("");
    const genderFemaleRef = useRef("");
    const qualifationRef = useRef("");
    const passwordRef = useRef("");
    const confirmPasswordRef = useRef("");
    const termsRef = useRef("");

    function addAgent() {
    
        let genderval = "";
        if(genderMaleRef.current.checked) {
            genderval = "male";
        }
        else if(genderFemaleRef.current.checked) {
            genderval = "female";
        }

        let user = {
            "firstName": firstNameRef.current.value,
            "lastName": lastNameRef.current.value,
            "email": emailRef.current.value,
            "dob": dobRef.current.value,
            "gender": genderMaleRef.current.checked ? "male" : "female",
            "qualification": qualifationRef.current.value,
            "password": passwordRef.current.value
        }

        let data = {
            method: "POST",
            headers: {
                "content-type": "application/json"
            },
            body: JSON.stringify(user)
        }

        saveAgent(data).then(res=>{
            alert("User Added");
        });
    }

    return (
       <Box mt={1}>
            <Container maxWidth="sm" sx={{border: "1px solid gray"}}>
                <Box component={"h3"}>Agent Registration</Box>
                <Grid container>
                    <Grid item md={6} xs={12} mt={2}>
                        <FormControl fullWidth>
                            <InputLabel>First Name</InputLabel>
                            <Input inputRef={firstNameRef}></Input>
                        </FormControl>
                    </Grid>
                    <Grid item md={6} xs={12} mt={2}>
                        <FormControl fullWidth>
                            <InputLabel>Last Name</InputLabel>
                            <Input inputRef={lastNameRef}></Input>
                        </FormControl>
                    </Grid>
                </Grid>

                <Box mt={2}>
                    <TextField type="email" fullWidth label="Email" variant="standard" inputRef={emailRef}></TextField>
                </Box>

                <Box mt={2}>
                    <InputLabel>DOB</InputLabel>
                    <TextField type="date" fullWidth variant="standard" inputRef={dobRef}></TextField>
                </Box>

                {/* <Box mt={2}>
                    <Radio name="gender" value="male"></Radio> Male
                    <Radio name="gender" value="female"></Radio> FeMale
                </Box> */}

                {/* <Box mt={2}>
                    <RadioGroup>
                        <Radio name="gender" value="male"></Radio> Male
                        <Radio name="gender" value="female"></Radio> FeMale
                    </RadioGroup>
                </Box> */}

                <Box mt={2}>
                    <FormControl>
                        <FormLabel>Gender</FormLabel>
                        <RadioGroup>
                            <FormControlLabel control={<Radio></Radio>} value="male" label="Male" inputRef={genderMaleRef}></FormControlLabel>
                            <FormControlLabel control={<Radio></Radio>} value="female" label="FeMale" inputRef={genderFemaleRef}></FormControlLabel>
                        </RadioGroup>
                    </FormControl>
                </Box>
                
                <Box mt={2}>
                    <FormLabel>Qualification</FormLabel>
                    <Select size="small" fullWidth inputRef={ qualifationRef }>
                        <MenuItem value="graduate">Graduate</MenuItem>
                        <MenuItem value="undergraduate">Under Graduate</MenuItem>
                    </Select>
                </Box>

                <Box mt={2}>
                    <TextField type="password" fullWidth label="Password" variant="standard" inputRef={passwordRef}></TextField>
                </Box>

                <Box mt={2}>
                    <TextField type="password" fullWidth label="Confirm Password" variant="standard" inputRef={confirmPasswordRef}></TextField>
                </Box>

                <Box mt={2}>
                    <Checkbox inputRef={termsRef}></Checkbox>
                    <FormLabel>Agree terms & Conditions.</FormLabel>
                </Box>

                <Box mt={2} mb={2}>
                    <Button variant="contained" color="success" onClick={()=>{
                        addAgent()
                    }}>Register</Button>
                    <Button variant="contained" color="info" sx={{marginLeft: "5px"}}>Cancel</Button>
                </Box>


            </Container>
            
       </Box>
    )
}
import { Box, Grid } from "@mui/material";
import { GridCell } from "./grid-cell/grid-cell";
import { GridHeader } from "./grid-header/grid-header";


export function GridComponent() {
    let headers = ["Id", "Name", "Email", "Phone Number"]
    return (
        <Box>
            <Grid container>
                <GridHeader headers={headers}></GridHeader>

                <Grid container>
                    <Grid item xs={3}>
                        <GridCell data={"id"}></GridCell>
                    </Grid>
                    <Grid item xs={3}>
                        <GridCell data={"name"}></GridCell>
                    </Grid>
                    <Grid item xs={3}>
                        <GridCell data={"Email"}></GridCell>
                    </Grid>
                    <Grid item xs={3}>
                        <GridCell data={"Phone Number"}></GridCell>
                    </Grid>
                </Grid>
                
            </Grid>
        </Box>
    )
}
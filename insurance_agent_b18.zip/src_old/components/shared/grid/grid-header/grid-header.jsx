import { Box, Grid } from "@mui/material"


export const GridHeader = ({headers}) => {
    return (
        <Grid container>            
                {
                    headers && headers.map((value, index, arr)=> HeaderCell(value))
                }
        </Grid>
    )
}


function HeaderCell(value) {
    return (
        <Grid item xs={3} sx={{textAlign: "center", fontWeight: "bold", backgroundColor: "#D3D3D3", padding: "5px", border: "1px solid gray"}}>
            {value}
        </Grid>
    )
}
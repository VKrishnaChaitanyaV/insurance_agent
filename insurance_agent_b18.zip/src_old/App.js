import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import { Layout } from './components/layout/layout'; 
import { BrowserRouter } from 'react-router-dom';
import { Login } from './components/login/login';
import { Registration } from './components/registration/registration';

function App() {
  return (
    // <BrowserRouter>
    //   <Layout></Layout>
    // </BrowserRouter>
    // <Login></Login>
    <Registration></Registration>
  );
}

export default App;

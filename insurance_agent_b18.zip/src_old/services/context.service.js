

export function getData(url) {
    return fetch(url).then(res=>res.json());
}

export function saveData(url, data) {
    return fetch(url, data).then(res=>res.json());
}

export function updateData(url, id, data) {
    return fetch(url+id, data).then(res=>res.json());
}

